// Demo source file for kind=code: DOM sink without sanitisation.
export function renderComment(container, comment) {
  container.innerHTML = comment.body;
}
