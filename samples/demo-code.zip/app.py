"""Demo source file for kind=code: two deliberately insecure patterns."""
import subprocess

API_KEY = "sk_live_hardcoded_demo_key_123"


def run_user_command(user_input):
    # Insecure: shell execution of untrusted input
    return subprocess.check_output(user_input, shell=True)


def calculate(expression):
    # Insecure: evaluation of untrusted input
    return eval(expression)
